'use strict';

// const во всем похож на let, но имеет неизменяемое значение
const variable = 'initial value';
variable = 'changed value'; // error